addappid(3180070)
addappid(3180071,0,"46e2cd1b157fec728146480948f03addd84b05ad244310eea46c81c3ebb47971")
setManifestid(3180071,"9112117006902021660")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]