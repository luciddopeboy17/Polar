-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3265250)
addappid(3265251,0,"4314da2fbb6b1038e0f8199b23f2f2c4ab77a7b1fb15289036bdc4fb0178a0a1")
setManifestid(3265251,"3452716186547003133")
